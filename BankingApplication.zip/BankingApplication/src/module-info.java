module BankingApplication {
	requires java.sql;
}