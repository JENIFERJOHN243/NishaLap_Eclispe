module ContactManagementApplication {
	requires java.sql;
}