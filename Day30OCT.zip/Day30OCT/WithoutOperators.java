package task;

import java.util.Scanner;

public class WithoutOperators {

	public static void main(String[] args) {
		getInput();
	}

	private static void getInput() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a Number");
		int input = scanner.nextInt();
		multiplyWith15(input);
		evenInteger(input);
		calculateValue(input);
	}

	private static void calculateValue(int input) {
		System.out.println("Value with 15 * n/16 : "+(((input<< 4) - input) >> 4) );
	}

	private static void evenInteger(int input) {
		System.out.println("Even Integer with 7.5 : "+(((input << 4) - input) >> 1 ));
	}

	private static void multiplyWith15(int input) {
		System.out.println("Multiply with 15 : "+((input<<4)-input));
	}

}
